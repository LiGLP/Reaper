import json
import urllib.request
import webbrowser
import os
import sys 

class IPAddressLocator:
    def __init__(self):
        self.R = '\033[91m'
        self.Y = '\033[93m'
        self.G = '\033[92m'
        self.CY = '\033[96m'
        self.W = '\033[97m'
        self.path = os.path.isfile('/data/data/com.termux/files/usr/bin/bash')

    def start(self):
        os.system('clear')
        print(self.CY + """
██╗██████╗ ████████╗██████╗  █████╗  ██████╗██╗  ██╗███████╗██████╗ 
██║██╔══██╗╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗
██║██████╔╝   ██║   ██████╔╝███████║██║     █████╔╝ █████╗  ██████╔╝
██║██╔═══╝    ██║   ██╔══██╗██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗
██║██║        ██║   ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║
╚═╝╚═╝        ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝ by LiGLP  """ + self.Y + """V2""" + self.G + """
        
        
        
        
        """ + self.R + """""" + self.Y + """""" + self.CY + """""" + self.Y + """""" + self.R + """""")

    def m3(self):
        try:
            print(self.R + """\n
    """ + self.Y + """Option auswählen""" + self.G + """ """ + self.Y + """
    
    1)""" + self.G + """Überprüfen Sie Ihre IP-Info""" + self.Y + """
    2)""" + self.G + """Überprüfen Sie andere IP-Info""" + self.Y + """
    3)""" + self.G + """ Verlassen
    """)
            ch = int(input(self.CY + "Geben Sie Ihre Wahl ein: " + self.W))
            if ch == 1:
                self.main2()
                self.m3()
            elif ch == 2:
                self.main()
                self.m3()
            elif ch == 3:
                print(self.Y + "Verlassen................" + self.W)
                sys.exit(0)
            else:
                print(self.R + "\nUngültige Auswahl! Bitte versuchen Sie es erneut\n")
                self.m3()
        except ValueError:
            print(self.R + "\nUngültige Auswahl! Bitte versuchen Sie es erneut\n")
            self.m3()

    def finder(self, u):
        try:
            try:
                response = urllib.request.urlopen(u)
                data = json.load(response)

                print(self.R + "\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
                print(self.Y + '\n>>>' + self.CY + ' IP-Adressdetails\n ')
                print(self.G + "1) IP-Adresse : " + self.Y, data['query'], '\n')
                print(self.G + "2) Organisation : " + self.Y, data['org'], '\n')
                print(self.G + "3) Stadt : " + self.Y, data['city'], '\n')
                print(self.G + "4) Region : " + self.Y, data['regionName'], '\n')
                print(self.G + "5) Land : " + self.Y, data['country'], '\n')
                print(self.G + "6) Standort\n")
                print(self.G + "\tBreitengrad : " + self.Y, data['lat'], '\n')
                print(self.G + "\tLängengrad : " + self.Y, data['lon'], '\n')
                l = 'https://www.google.com/maps/place/' + str(data['lat']) + '+' + str(data['lon'])
                print(self.R + "\n#" + self.Y + " Google Maps-Link : " + self.CY, l)
                path = os.path.isfile('/data/data/com.termux/files/usr/bin/bash')
                if path:
                    link = 'am start -a android.intent.action.VIEW -d ' + str(l)
                    pr = input(self.R + "\n>>" + self.Y + " Link im Browser öffnen?" + self.G + " (y|n): " + self.W)
                    if pr == "y":
                        lnk = str(link) + " > /dev/null"
                        os.system(str(lnk))
                        self.start()
                        self.m3()
                    elif pr == "n":
                        print("\nÜberprüfen Sie eine andere IP oder beenden Sie mit Strg + C\n\n")
                        self.start()
                        self.m3()
                    else:
                        print("\nUngültige Wahl! Bitte versuchen Sie es erneut\n")
                        self.m3()
                else:
                    pr = input(self.R + "\n>>" + self.Y + " Link im Browser öffnen?" + self.G + " (y|n): " + self.W)
                    if pr == "y":
                        webbrowser.open(l, new=0)
                        self.start()
                        self.m3()
                    elif pr == "n":
                        print(self.R + "\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
                        print(self.Y + "\nÜberprüfen Sie eine andere IP oder beenden Sie mit " + self.R + "Strg + C\n\n")
                        self.start()
                        self.m3()
                    else:
                        print(self.R + "\nUngültige Wahl! Bitte versuchen Sie es erneut\n")
                        self.m3()
                return
            except KeyError:
                print(self.R + "\nFehler! Ungültige IP-/Webseitenadresse!\n" + self.W)
                self.m3()
        except urllib.error.URLError:
            print(self.R + "\nFehler!" + self.Y + " Bitte überprüfen Sie Ihre Internetverbindung!\n" + self.W)
            exit()

    def main(self):
        u = input(self.G + "\n>>> " + self.Y + "Geben Sie die IP-Adresse/Webseitenadresse ein:" + self.W + " ")
        if u == "":
            print(self.R + "\nGeben Sie eine gültige IP-Adresse/Webseitenadresse ein!")
            self.main()
        else:
            url = 'http://ip-api.com/json/' + u
            self.finder(url)

    def main2(self):
        url = 'http://ip-api.com/json/'
        self.finder(url)

    def run(self):
        try:
            self.start()
            self.m3()
        except KeyboardInterrupt:
            print(self.Y + "\nUnterbrochen! Einen schönen Tag noch :)" + self.W)

if __name__ == "__main__":
    ip_locator = IPAddressLocator()
    ip_locator.run()
