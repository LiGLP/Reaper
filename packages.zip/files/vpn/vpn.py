import time
import random

def vpn_connect(server_name, ip_address):
    print("Verbindung wird hergestellt...")
    time.sleep(random.uniform(1, 3))
    print(f"Verbindung zu VPN-Server '{server_name}' wird aufgebaut...")
    time.sleep(random.uniform(1, 2))
    print("Authentifizierung läuft...")
    time.sleep(random.uniform(1, 2))
    print("Verbindung erfolgreich hergestellt!")
    print(f"IP-Adresse: {ip_address}")
    print("Tunnel-Protokoll: OpenVPN")
    print("Verbindung aktiv...")

    while True:
        time.sleep(random.uniform(5, 10))
        print("Daten werden durch den Tunnel geleitet...")

if __name__ == "__main__":
    server_name = "reaper"
    ip_address = "185.254.96.192"
    vpn_connect(server_name, ip_address)
